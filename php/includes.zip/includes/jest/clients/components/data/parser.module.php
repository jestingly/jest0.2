<?php

//-------------------------
// JestParser Class
//-------------------------
// Utility class for validating/sanitizing JSON input arrays
// Used to prevent malformed or unsafe data from propagating
class JestParser extends Gamepeice {
	// Object propert(ies)

	//-------------------------
	// Constructor
	//-------------------------
	// Initializes the module.
	// * $client	- [object] Jest application owning the gamepiece.
	public function __construct( $client ) {
		// Call the parent constructor
		parent::__construct( $client );
	}

	//-------------------------
	// Static: Parse JSON Body
	//-------------------------
	// Reads raw php://input and decodes to [array].
	// RETURNS: [array|null] parsed input or null on error.
	public static function fromJSON() {
		$raw	= file_get_contents('php://input');
		$data	= json_decode( $raw, true );

		return is_array($data) ? $data : null;
	}

	//-------------------------
	// Static: Require Fields
	//-------------------------
	// Validates presence of required keys in $data.
	// RETURNS: [bool] true if all fields exist, false otherwise.
	// * $data		- [array] input array
	// * $fields	- [array] list of required field names
	public static function hasFields( $data, $fields ) {
		foreach ( $fields as $field )
			if ( !isset($data[$field]) || $data[$field]==='' )
				return false;

		return true;
	}

	//-------------------------
	// Static: Sanitize User Data
	//-------------------------
	// Strips unwanted characters and trims strings.
	// RETURNS: [array] sanitized result
	// * $data		- [array] raw input
	// * $fields	- [array] fields to sanitize
	public static function sanitize( $data, $fields ) {
		$out = [];

		foreach ( $fields as $field ) {
			if ( isset($data[$field]) )
				$out[$field] = trim( filter_var( $data[$field], FILTER_SANITIZE_STRING ) );
			else
				$out[$field] = null;
		}

		return $out;
	}

	//-------------------------
	// Static: Validate Username
	//-------------------------
	// Basic validation of [username] format.
	// RETURNS: [bool] whether valid.
	// * $username - [string]
	public static function validateUsername( $username ) {
		return is_string($username) && preg_match('/^[a-zA-Z0-9_\-]{3,20}$/', $username);
	}

	//-------------------------
	// Static: Validate Email
	//-------------------------
	// Basic validation of [email] format.
	// RETURNS: [bool] whether valid.
	// * $email - [string]
	public static function validateEmail( $email ) {
		return is_string($email) && filter_var( $email, FILTER_VALIDATE_EMAIL );
	}

	//-------------------------
	// Static: Validate Password
	//-------------------------
	// Password rules: min 6 chars, at least 1 letter and 1 number.
	// RETURNS: [bool] whether valid.
	// * $password - [string]
	public static function validatePassword( $password ) {
		if ( !is_string($password) || strlen($password) < 6 ) return false;
		return preg_match('/[a-zA-Z]/', $password) && preg_match('/[0-9]/', $password);
	}

	//-------------------------
	// Static: Parse + Validate Credentials
	//-------------------------
	// Reads and validates a standard login/register input.
	// RETURNS: [array|null] sanitized values or null on failure.
	// * $data - [array] raw input array
	public static function parseCredentials( $data ) {
		//--------------------------------
		// Require username/email/password
		//--------------------------------
		if ( !self::hasFields( $data, ['username','email','password'] ) ) return null;

		//--------------------------------
		// Sanitize inputs
		//--------------------------------
		$clean = self::sanitize( $data, ['username','email','password'] );

		//--------------------------------
		// Validate individual fields
		//--------------------------------
		if (
			!self::validateUsername( $clean['username'] ) ||
			!self::validateEmail( $clean['email'] ) ||
			!self::validatePassword( $clean['password'] )
		) return null;

		return $clean;
	}

	//-------------------------
	// Static: Parse + Validate Credentials
	//-------------------------
	// Reads and validates a set of user fields.
	// RETURNS: [array|null] sanitized values or null on failure.
	// * $data   - [array] raw input
	// * $fields - [array] expected field names (ex: ['username','email','password'])
	public static function parseCredentials( $data, $fields ) {
		//--------------------------------
		// Validate required fields
		//--------------------------------
		if ( !self::hasFields( $data, $fields ) ) return null;

		//--------------------------------
		// Sanitize all fields
		//--------------------------------
		$clean = self::sanitize( $data, $fields );

		//--------------------------------
		// Field-specific validation (if exists)
		//--------------------------------
		foreach ( $fields as $key ) {
			switch ( $key ) {
				case 'username':
					if ( !self::validateUsername($clean[$key]) ) return null;
					break;

				case 'email':
					if ( !self::validateEmail($clean[$key]) ) return null;
					break;

				case 'password':
					if ( !self::validatePassword($clean[$key]) ) return null;
					break;
			}
		}

		return $clean;
	}
}

?>
