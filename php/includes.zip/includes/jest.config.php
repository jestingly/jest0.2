<?php

//-------------------------
// JestConfig Class
//-------------------------
// Core CMS [object] class for user configuration.
class JestConfig {
	// MySQL login credentials.
	$DB_HOST	= 'localhost';
	$DB_NAME	= 'jest_play';
	$DB_USER	= 'root';
	$DB_PASS	= 'root';
}

?>
