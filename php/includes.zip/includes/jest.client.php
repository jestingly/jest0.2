<?php

//-------------------------
// Jest Class
//-------------------------
// Core CMS [object] class for handling all [objects].
class Jest {
	// Object propert(ies)
	public $config;		// [object] JestConfig for user system customization.
	public $mysql;		// [object] JestMySQL module for MySQL db interfacing.
	public $parser;		// [object] JestParser module for parsing data.
	public $user;		// [object] JestUser module for user recognition.
	public $login;		// [object] JestLogin handler for user login/registration.

	//-------------------------
	// Constructor
	//-------------------------
	// Initializes the client.
	public function __construct() {
		// Create configuration [object].
		$this->config	= new JestConfig( $this );
		// Begin MySQL connection.
		$this->mysql	= new JestMySQL( $this );
		// Create core parsing [object].
		$this->parser	= new JestParser( $this );
		// Begin user session.
		$this->user		= new JestUser( $this );
		// Begin user login connection.
		$this->login	= new JestLogin( $this );
	}
}

//-------------------------
// Create JEST Client [object]
//-------------------------
// Core Jest [object] application client.
global $jest;
$jest	= new Jest();

?>
