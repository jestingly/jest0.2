<?php
//----------------------------------------------
// check.php – Verifies active session login
//----------------------------------------------

//---------------------------
// Suppress all PHP errors
//---------------------------
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

//---------------------------
// Output will be JSON
//---------------------------
header('Content-Type: application/json');

//---------------------------
// Start or resume session
//---------------------------
require_once '../include.php';

//---------------------------
// Return login state as JSON
//---------------------------
$response	=
	json_encode([
		'loggedIn'	=> isset( $_SESSION['user'] ),
		'user'		=> $_SESSION['user'] ?? null
		]);
//error_log( $response );
echo $response;

exit;
