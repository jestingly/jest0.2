<?php
//--------------------------------------------
// register.php – Handles new account creation
//--------------------------------------------

require '../include.php'; // Start client

//-------------------------------
// Set JSON response header
//-------------------------------
header('Content-Type: application/json');

//-------------------------------
// Disable error output (breaks JSON)
//-------------------------------
ini_set('display_errors', 0);
error_reporting(0);
ini_set('output_buffering', 'off');
ob_clean();

//---------------------------
// Get POST JSON and decode
//---------------------------
$raw	= file_get_contents('php://input');
$data	= json_decode( $raw, true );

//---------------------------
// Validate input JSON
//---------------------------
if ( !is_array($data) || !isset($data['username'], $data['email'], $data['password']) ) {
	http_response_code(400); // Bad Request
	echo json_encode([ 'error' => 'Invalid input.' ]);
	exit;
}

//-------------------------------
// Validate required fields
//-------------------------------
$username = $data['username'] ?? '';
$email    = $data['email'] ?? '';
$password = $data['password'] ?? '';

if ( !$username || !$email || !$password ) {
	echo json_encode([ 'success' => false, 'error' => 'Missing required fields.' ]);
	exit;
}

//-------------------------------
// Run registration logic
//-------------------------------
$auth		= new LoginModule( $pdo );
$response	= json_encode( $auth->register( $username, $email, $password ) );
error_log( $response );
echo $response;

exit;
