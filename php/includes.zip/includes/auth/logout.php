<?php
//-----------------------------------------
// Logout Handler
//-----------------------------------------
// Ends the current user session and returns
// a success flag via JSON response.
//-----------------------------------------

require '../session.php';					// Load session to destroy it
session_destroy();							// Fully terminate the session

//-----------------------------------------
// Output Response
//-----------------------------------------
$response =									// Indicate successful logout
	json_encode([
		'success' => true
		]);
error_log( $response );
echo $response;
exit;										// Halt further PHP execution
