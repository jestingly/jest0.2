<?php
//-----------------------------------------
// Login Handler
//-----------------------------------------
// Accepts JSON POST data with username
// and password, validates credentials,
// and starts session if successful.
//-----------------------------------------

require '../session.php';					// Load session management
require '../config.php';					// Load DB configuration (PDO)
require '../login.module.php';				// Modular login logic

header('Content-Type: application/json');	// Force JSON return

//-----------------------------------------
// Decode JSON input from fetch() body
//-----------------------------------------
// Capture raw POST body and parse JSON
$data	= json_decode( file_get_contents('php://input'), true );

//----------------------------------------
// Validate and sanitize input
//----------------------------------------
if ( !is_array($data) || !isset($data['username'], $data['password']) ) {
	http_response_code(400);
	echo json_encode([ 'success'=>false, 'error'=>'Missing required fields.' ]);
	exit;
}

$username	= trim( $data['username'] );
$password	= $data['password'];

//----------------------------------------
// Run Login Attempt
//----------------------------------------
$auth		= new LoginModule( $pdo );
$response	= $auth->login( $username, $password );

//-----------------------------------------
// Output Response
//-----------------------------------------
echo = json_encode( $result );				// Return success or failure

?>
