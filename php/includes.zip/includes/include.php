<?php

// Module include(s).
require_once 'jest/clients/components/gamepiece.module.php';
require_once 'jest/clients/components/connect/mysql.module.php';
require_once 'jest/clients/components/data/parser.module.php';
require_once 'jest/clients/components/auth/login.module.php';
require_once 'jest/clients/components/auth/user.module.php';

// Client include(s).
require_once 'jest.config.php';
require_once 'jest.client.php';

?>
